#ifndef __pp9k__graphicsView__
#define __pp9k__graphicsView__

#include "view.h"

class graphicsView: public View {
    
public:
};

#endif
