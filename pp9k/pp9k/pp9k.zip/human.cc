#include "human.h"

Human::Human(int playerNum): Player(playerNum) {}
