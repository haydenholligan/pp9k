#include "human.h"

Human::Human(int playerNum, Game *g): Player(playerNum, g) {}
