#ifndef __pp9k__human__
#define __pp9k__human__

#include "game.h"
#include "player.h"

class Human: public Player {
public:
    Human(int playerNum, Game *g);
};

#endif
