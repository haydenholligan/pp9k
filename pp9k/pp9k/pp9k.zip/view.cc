#include "view.h"

View::View() {
    
}

View::~View() {
    
}
